# WorkTonix Workspace — Secure Internal Workspace Launcher

Production-grade internal tool for managing, securing, and launching browser workspaces (AdsPower profiles) with role-based access control, encrypted secrets, and full audit logging.

## Architecture

```
┌──────────────────────────────────────────────────────┐
│                    Frontend (Next.js 14)              │
│  App Router · TailwindCSS · shadcn/ui · TypeScript   │
│  JWT in-memory · HttpOnly refresh cookie             │
└──────────────────┬───────────────────────────────────┘
                   │ /api/* proxy (rewrites)
┌──────────────────▼───────────────────────────────────┐
│                   Backend (NestJS)                    │
│  Passport JWT · RBAC Guards · AES-256-GCM Secrets    │
│  Rate Limiting · Helmet · Audit Interceptor          │
├────────────────┬─────────────────┬───────────────────┤
│  PostgreSQL    │     Redis       │   AdsPower API     │
│  (Prisma ORM)  │  (Token cache)  │   (Browser mgmt)  │
└────────────────┴─────────────────┴───────────────────┘
```

## Quick Start

```bash
# 1. Start infrastructure
docker compose up -d

# 2. Backend
cd backend
cp .env.example .env   # edit secrets!
npm install
npx prisma generate
npx prisma migrate dev
npm run prisma:seed
npm run start:dev

# 3. Frontend
cd frontend
npm install
npm run dev
```

Default login: `admin@worktonix.io` / `Admin@1234`

## Security Features

| Feature | Implementation |
|---------|---------------|
| Access Tokens | JWT, 15-minute expiry |
| Refresh Tokens | Opaque, SHA-256 hashed, stored in DB + Redis, HttpOnly cookie |
| Token Rotation | Old refresh token revoked on each refresh |
| Secrets | AES-256-GCM encryption at rest, never exposed to frontend |
| Passwords | bcrypt with 12 salt rounds |
| RBAC | Admin / Manager / Operator roles with guard enforcement |
| Rate Limiting | 60 req/min per IP via @nestjs/throttler |
| Input Validation | class-validator with whitelist + forbidNonWhitelisted |
| Headers | Helmet for security headers |
| CORS | Strict origin allowlist |
| Audit Trail | Structured logs in PostgreSQL for every sensitive action |

## API Endpoints

| Method | Path | Description | Auth |
|--------|------|-------------|------|
| POST | /api/auth/register | Register user | - |
| POST | /api/auth/login | Login | - |
| POST | /api/auth/refresh | Refresh token | Cookie |
| POST | /api/auth/logout | Logout | JWT |
| GET | /api/users/me | Current user | JWT |
| GET | /api/users | List users | Admin |
| PATCH | /api/users/:id | Update user | Admin |
| DELETE | /api/users/:id | Delete user | Admin |
| GET | /api/workspaces | List workspaces | JWT |
| POST | /api/workspaces | Create workspace | JWT |
| GET | /api/workspaces/:id | Get workspace | JWT |
| PATCH | /api/workspaces/:id | Update workspace | Owner/Admin |
| DELETE | /api/workspaces/:id | Delete workspace | Owner/Admin |
| POST | /api/workspaces/:id/launch | Launch workspace | JWT |
| POST | /api/workspaces/:id/stop | Stop workspace | JWT |
| POST | /api/workspaces/:wid/secrets | Add secret | JWT |
| GET | /api/workspaces/:wid/secrets | List secrets (keys only) | JWT |
| PATCH | /api/workspaces/:wid/secrets/:id | Update secret | JWT |
| DELETE | /api/workspaces/:wid/secrets/:id | Delete secret | JWT |
| GET | /api/audit | Query audit logs | Admin/Manager |
