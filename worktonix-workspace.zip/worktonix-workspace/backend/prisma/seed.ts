import { PrismaClient, Role } from '@prisma/client';
import * as bcrypt from 'bcrypt';

const prisma = new PrismaClient();

async function main(): Promise<void> {
  const passwordHash = await bcrypt.hash('Admin@1234', 12);

  await prisma.user.upsert({
    where: { email: 'admin@worktonix.io' },
    update: {},
    create: {
      email: 'admin@worktonix.io',
      passwordHash,
      displayName: 'System Admin',
      role: Role.ADMIN,
    },
  });

  console.log('Seed complete: admin@worktonix.io / Admin@1234');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
