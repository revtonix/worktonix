import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { ThrottlerModule, ThrottlerGuard } from '@nestjs/throttler';
import { APP_GUARD } from '@nestjs/core';
import { PrismaModule } from './prisma/prisma.module';
import { AuthModule } from './auth/auth.module';
import { UsersModule } from './users/users.module';
import { WorkspacesModule } from './workspaces/workspaces.module';
import { SecretsModule } from './secrets/secrets.module';
import { AuditModule } from './audit/audit.module';
import { ConfigModule as AppConfigModule } from './config/config.module';

@Module({
  imports: [
    // Environment variables — loaded once, available everywhere
    ConfigModule.forRoot({ isGlobal: true }),

    // Rate limiting — 60 requests per minute per IP
    ThrottlerModule.forRoot([{ ttl: 60_000, limit: 60 }]),

    // Internal modules
    PrismaModule,
    AppConfigModule,
    AuthModule,
    UsersModule,
    WorkspacesModule,
    SecretsModule,
    AuditModule,
  ],
  providers: [
    // Apply rate limiting globally
    { provide: APP_GUARD, useClass: ThrottlerGuard },
  ],
})
export class AppModule {}
