import { IsEmail, IsEnum, IsOptional, IsString, MinLength } from 'class-validator';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Role } from '@prisma/client';

export class RegisterDto {
  @ApiProperty({ example: 'admin@worktonix.io' })
  @IsEmail()
  email!: string;

  @ApiProperty({ example: 'strongP@ssw0rd' })
  @IsString()
  @MinLength(8)
  password!: string;

  @ApiProperty({ example: 'Admin User' })
  @IsString()
  @MinLength(2)
  displayName!: string;

  @ApiPropertyOptional({ enum: Role, default: Role.OPERATOR })
  @IsEnum(Role)
  @IsOptional()
  role?: Role;
}
