import { createParamDecorator, ExecutionContext } from '@nestjs/common';
import { JwtPayload } from '../types/request.types';

/** Extract the authenticated user from the request */
export const CurrentUser = createParamDecorator(
  (_data: unknown, ctx: ExecutionContext): JwtPayload => {
    const request = ctx.switchToHttp().getRequest();
    return request.user as JwtPayload;
  },
);
