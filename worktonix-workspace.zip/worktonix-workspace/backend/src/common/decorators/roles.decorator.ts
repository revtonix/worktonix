import { SetMetadata } from '@nestjs/common';
import { Role } from '@prisma/client';

export const ROLES_KEY = 'roles';

/** Restrict endpoint access to specific roles */
export const Roles = (...roles: Role[]) => SetMetadata(ROLES_KEY, roles);
