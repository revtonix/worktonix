import {
  CallHandler,
  ExecutionContext,
  Injectable,
  NestInterceptor,
} from '@nestjs/common';
import { Observable, tap } from 'rxjs';
import { Reflector } from '@nestjs/core';
import { AuditService } from '../../audit/audit.service';
import { AUDIT_ACTION_KEY } from '../decorators/audit.decorator';
import { AuditAction } from '@prisma/client';
import { JwtPayload } from '../types/request.types';

@Injectable()
export class AuditInterceptor implements NestInterceptor {
  constructor(
    private readonly reflector: Reflector,
    private readonly auditService: AuditService,
  ) {}

  intercept(context: ExecutionContext, next: CallHandler): Observable<unknown> {
    const action = this.reflector.get<AuditAction>(
      AUDIT_ACTION_KEY,
      context.getHandler(),
    );

    if (!action) return next.handle();

    const request = context.switchToHttp().getRequest();
    const user: JwtPayload | undefined = request.user;
    const ip =
      request.ip || request.headers['x-forwarded-for'] || 'unknown';
    const userAgent = request.headers['user-agent'] || 'unknown';

    return next.handle().pipe(
      tap((responseBody) => {
        // Fire-and-forget — don't block the response
        const targetId =
          request.params?.id ??
          (responseBody as { id?: string } | undefined)?.id ??
          undefined;

        this.auditService
          .log({
            action,
            userId: user?.sub,
            targetType: context.getClass().name.replace('Controller', ''),
            targetId,
            metadata: { method: request.method, path: request.url },
            ipAddress: ip,
            userAgent,
          })
          .catch(() => {
            /* swallow — audit should never crash the app */
          });
      }),
    );
  }
}
