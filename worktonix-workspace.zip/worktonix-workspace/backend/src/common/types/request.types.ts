import { Role } from '@prisma/client';

/** Payload embedded in every JWT access token */
export interface JwtPayload {
  sub: string; // userId
  email: string;
  role: Role;
}

/** Express request augmented with the authenticated user */
export interface AuthenticatedRequest extends Request {
  user: JwtPayload;
}
