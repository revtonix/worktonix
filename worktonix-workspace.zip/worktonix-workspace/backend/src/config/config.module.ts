import { Global, Module } from '@nestjs/common';
import { RedisService } from './redis.service';
import { EncryptionService } from './encryption.service';

@Global()
@Module({
  providers: [RedisService, EncryptionService],
  exports: [RedisService, EncryptionService],
})
export class ConfigModule {}
