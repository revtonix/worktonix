import { IsString, MinLength } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

export class CreateSecretDto {
  @ApiProperty({ example: 'API_KEY' })
  @IsString()
  @MinLength(1)
  key!: string;

  @ApiProperty({ example: 'sk-live-abc123' })
  @IsString()
  @MinLength(1)
  value!: string;
}
