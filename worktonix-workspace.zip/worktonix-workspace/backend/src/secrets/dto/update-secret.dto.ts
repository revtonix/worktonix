import { IsString, MinLength } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

export class UpdateSecretDto {
  @ApiProperty({ example: 'sk-live-updated456' })
  @IsString()
  @MinLength(1)
  value!: string;
}
