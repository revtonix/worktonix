import {
  Controller,
  Get,
  Post,
  Patch,
  Delete,
  Param,
  Body,
  UseGuards,
  UseInterceptors,
  ParseUUIDPipe,
} from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation } from '@nestjs/swagger';
import { AuditAction } from '@prisma/client';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { RolesGuard } from '../common/guards/roles.guard';
import { Audit } from '../common/decorators/audit.decorator';
import { AuditInterceptor } from '../common/interceptors/audit.interceptor';
import { CurrentUser } from '../common/decorators/current-user.decorator';
import { JwtPayload } from '../common/types/request.types';
import { SecretsService, SecretSummary } from './secrets.service';
import { CreateSecretDto } from './dto/create-secret.dto';
import { UpdateSecretDto } from './dto/update-secret.dto';

@ApiTags('Secrets')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, RolesGuard)
@UseInterceptors(AuditInterceptor)
@Controller('workspaces/:workspaceId/secrets')
export class SecretsController {
  constructor(private readonly secretsService: SecretsService) {}

  @Post()
  @Audit(AuditAction.SECRET_CREATED)
  @ApiOperation({ summary: 'Add a secret to a workspace' })
  async create(
    @Param('workspaceId', ParseUUIDPipe) workspaceId: string,
    @Body() dto: CreateSecretDto,
    @CurrentUser() user: JwtPayload,
  ): Promise<SecretSummary> {
    return this.secretsService.create(workspaceId, dto, user);
  }

  @Get()
  @ApiOperation({ summary: 'List secrets for a workspace (keys only)' })
  async findAll(
    @Param('workspaceId', ParseUUIDPipe) workspaceId: string,
    @CurrentUser() user: JwtPayload,
  ): Promise<SecretSummary[]> {
    return this.secretsService.findAllForWorkspace(workspaceId, user);
  }

  @Patch(':id')
  @Audit(AuditAction.SECRET_UPDATED)
  @ApiOperation({ summary: 'Update a secret value' })
  async update(
    @Param('workspaceId', ParseUUIDPipe) workspaceId: string,
    @Param('id', ParseUUIDPipe) id: string,
    @Body() dto: UpdateSecretDto,
    @CurrentUser() user: JwtPayload,
  ): Promise<SecretSummary> {
    return this.secretsService.update(workspaceId, id, dto, user);
  }

  @Delete(':id')
  @Audit(AuditAction.SECRET_DELETED)
  @ApiOperation({ summary: 'Delete a secret' })
  async remove(
    @Param('workspaceId', ParseUUIDPipe) workspaceId: string,
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser() user: JwtPayload,
  ): Promise<{ message: string }> {
    await this.secretsService.remove(workspaceId, id, user);
    return { message: 'Secret deleted' };
  }
}
