import {
  Injectable,
  NotFoundException,
  ForbiddenException,
  ConflictException,
} from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { EncryptionService } from '../config/encryption.service';
import { CreateSecretDto } from './dto/create-secret.dto';
import { UpdateSecretDto } from './dto/update-secret.dto';
import { JwtPayload } from '../common/types/request.types';
import { Role } from '@prisma/client';

/** Shape returned to the client — never includes the encrypted value */
export interface SecretSummary {
  id: string;
  workspaceId: string;
  key: string;
  createdAt: Date;
  updatedAt: Date;
}

@Injectable()
export class SecretsService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly encryption: EncryptionService,
  ) {}

  async create(
    workspaceId: string,
    dto: CreateSecretDto,
    user: JwtPayload,
  ): Promise<SecretSummary> {
    await this.assertWorkspaceAccess(workspaceId, user);

    // Check for duplicate key within the workspace
    const existing = await this.prisma.workspaceSecret.findUnique({
      where: { workspaceId_key: { workspaceId, key: dto.key } },
    });
    if (existing) {
      throw new ConflictException(`Secret "${dto.key}" already exists in this workspace`);
    }

    const { ciphertext, iv, authTag } = this.encryption.encrypt(dto.value);

    const secret = await this.prisma.workspaceSecret.create({
      data: {
        workspaceId,
        key: dto.key,
        encryptedValue: ciphertext,
        iv,
        authTag,
      },
    });

    return this.toSummary(secret);
  }

  async findAllForWorkspace(
    workspaceId: string,
    user: JwtPayload,
  ): Promise<SecretSummary[]> {
    await this.assertWorkspaceAccess(workspaceId, user);

    const secrets = await this.prisma.workspaceSecret.findMany({
      where: { workspaceId },
      orderBy: { key: 'asc' },
    });

    return secrets.map((s) => this.toSummary(s));
  }

  /** Decrypt and return the value — used only by the launcher, never by the API */
  async decryptValue(
    workspaceId: string,
    secretId: string,
    user: JwtPayload,
  ): Promise<string> {
    await this.assertWorkspaceAccess(workspaceId, user);

    const secret = await this.prisma.workspaceSecret.findFirst({
      where: { id: secretId, workspaceId },
    });
    if (!secret) throw new NotFoundException('Secret not found');

    return this.encryption.decrypt(secret.encryptedValue, secret.iv, secret.authTag);
  }

  async update(
    workspaceId: string,
    secretId: string,
    dto: UpdateSecretDto,
    user: JwtPayload,
  ): Promise<SecretSummary> {
    await this.assertWorkspaceAccess(workspaceId, user);

    const secret = await this.prisma.workspaceSecret.findFirst({
      where: { id: secretId, workspaceId },
    });
    if (!secret) throw new NotFoundException('Secret not found');

    const { ciphertext, iv, authTag } = this.encryption.encrypt(dto.value);

    const updated = await this.prisma.workspaceSecret.update({
      where: { id: secretId },
      data: { encryptedValue: ciphertext, iv, authTag },
    });

    return this.toSummary(updated);
  }

  async remove(
    workspaceId: string,
    secretId: string,
    user: JwtPayload,
  ): Promise<void> {
    await this.assertWorkspaceAccess(workspaceId, user);

    const secret = await this.prisma.workspaceSecret.findFirst({
      where: { id: secretId, workspaceId },
    });
    if (!secret) throw new NotFoundException('Secret not found');

    await this.prisma.workspaceSecret.delete({ where: { id: secretId } });
  }

  // ─── Helpers ───────────────────────────────────────────────────────

  private async assertWorkspaceAccess(
    workspaceId: string,
    user: JwtPayload,
  ): Promise<void> {
    const workspace = await this.prisma.workspace.findUnique({
      where: { id: workspaceId },
    });
    if (!workspace) throw new NotFoundException('Workspace not found');

    if (
      user.role !== Role.ADMIN &&
      user.role !== Role.MANAGER &&
      workspace.ownerId !== user.sub
    ) {
      throw new ForbiddenException('Access denied');
    }
  }

  private toSummary(secret: {
    id: string;
    workspaceId: string;
    key: string;
    createdAt: Date;
    updatedAt: Date;
  }): SecretSummary {
    return {
      id: secret.id,
      workspaceId: secret.workspaceId,
      key: secret.key,
      createdAt: secret.createdAt,
      updatedAt: secret.updatedAt,
    };
  }
}
