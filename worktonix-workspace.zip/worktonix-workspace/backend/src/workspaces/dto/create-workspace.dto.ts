import { IsObject, IsOptional, IsString, IsUrl, MinLength } from 'class-validator';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';

export class CreateWorkspaceDto {
  @ApiProperty({ example: 'Production Browser' })
  @IsString()
  @MinLength(2)
  name!: string;

  @ApiPropertyOptional({ example: 'Chrome profile for production tasks' })
  @IsString()
  @IsOptional()
  description?: string;

  @ApiProperty({ example: 'profile_abc123' })
  @IsString()
  profileId!: string;

  @ApiPropertyOptional({ example: 'https://app.example.com' })
  @IsUrl()
  @IsOptional()
  launchUrl?: string;

  @ApiPropertyOptional({ example: { headless: false, timeout: 30000 } })
  @IsObject()
  @IsOptional()
  config?: Record<string, unknown>;
}
