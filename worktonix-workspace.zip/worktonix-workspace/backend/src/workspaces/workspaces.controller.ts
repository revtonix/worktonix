import {
  Controller,
  Get,
  Post,
  Patch,
  Delete,
  Param,
  Body,
  UseGuards,
  UseInterceptors,
  ParseUUIDPipe,
} from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation } from '@nestjs/swagger';
import { AuditAction } from '@prisma/client';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { RolesGuard } from '../common/guards/roles.guard';
import { Audit } from '../common/decorators/audit.decorator';
import { AuditInterceptor } from '../common/interceptors/audit.interceptor';
import { CurrentUser } from '../common/decorators/current-user.decorator';
import { JwtPayload } from '../common/types/request.types';
import { WorkspacesService } from './workspaces.service';
import { CreateWorkspaceDto } from './dto/create-workspace.dto';
import { UpdateWorkspaceDto } from './dto/update-workspace.dto';

@ApiTags('Workspaces')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, RolesGuard)
@UseInterceptors(AuditInterceptor)
@Controller('workspaces')
export class WorkspacesController {
  constructor(private readonly workspacesService: WorkspacesService) {}

  @Post()
  @Audit(AuditAction.WORKSPACE_CREATED)
  @ApiOperation({ summary: 'Create a new workspace' })
  async create(
    @Body() dto: CreateWorkspaceDto,
    @CurrentUser() user: JwtPayload,
  ) {
    return this.workspacesService.create(dto, user);
  }

  @Get()
  @ApiOperation({ summary: 'List workspaces (scoped by role)' })
  async findAll(@CurrentUser() user: JwtPayload) {
    return this.workspacesService.findAll(user);
  }

  @Get(':id')
  @ApiOperation({ summary: 'Get workspace by ID' })
  async findOne(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser() user: JwtPayload,
  ) {
    return this.workspacesService.findById(id, user);
  }

  @Patch(':id')
  @Audit(AuditAction.WORKSPACE_UPDATED)
  @ApiOperation({ summary: 'Update workspace' })
  async update(
    @Param('id', ParseUUIDPipe) id: string,
    @Body() dto: UpdateWorkspaceDto,
    @CurrentUser() user: JwtPayload,
  ) {
    return this.workspacesService.update(id, dto, user);
  }

  @Delete(':id')
  @Audit(AuditAction.WORKSPACE_DELETED)
  @ApiOperation({ summary: 'Delete workspace' })
  async remove(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser() user: JwtPayload,
  ) {
    await this.workspacesService.remove(id, user);
    return { message: 'Workspace deleted' };
  }

  @Post(':id/launch')
  @Audit(AuditAction.WORKSPACE_LAUNCHED)
  @ApiOperation({ summary: 'Launch workspace' })
  async launch(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser() user: JwtPayload,
  ) {
    return this.workspacesService.launch(id, user);
  }

  @Post(':id/stop')
  @Audit(AuditAction.WORKSPACE_STOPPED)
  @ApiOperation({ summary: 'Stop workspace' })
  async stop(
    @Param('id', ParseUUIDPipe) id: string,
    @CurrentUser() user: JwtPayload,
  ) {
    return this.workspacesService.stop(id, user);
  }
}
