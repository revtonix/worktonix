import {
  Injectable,
  NotFoundException,
  ForbiddenException,
  Logger,
} from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { RedisService } from '../config/redis.service';
import { CreateWorkspaceDto } from './dto/create-workspace.dto';
import { UpdateWorkspaceDto } from './dto/update-workspace.dto';
import { JwtPayload } from '../common/types/request.types';
import { Role, Workspace, WorkspaceStatus } from '@prisma/client';

@Injectable()
export class WorkspacesService {
  private readonly logger = new Logger(WorkspacesService.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly redis: RedisService,
  ) {}

  // ─── CRUD ──────────────────────────────────────────────────────────

  async create(dto: CreateWorkspaceDto, user: JwtPayload): Promise<Workspace> {
    return this.prisma.workspace.create({
      data: {
        name: dto.name,
        description: dto.description,
        profileId: dto.profileId,
        launchUrl: dto.launchUrl,
        config: dto.config ?? {},
        ownerId: user.sub,
      },
    });
  }

  async findAll(user: JwtPayload): Promise<Workspace[]> {
    // Admins and managers see everything; operators see only their own
    const where =
      user.role === Role.ADMIN || user.role === Role.MANAGER
        ? {}
        : { ownerId: user.sub };

    return this.prisma.workspace.findMany({
      where,
      include: { owner: { select: { id: true, displayName: true, email: true } } },
      orderBy: { createdAt: 'desc' },
    });
  }

  async findById(id: string, user: JwtPayload): Promise<Workspace> {
    const workspace = await this.prisma.workspace.findUnique({
      where: { id },
      include: { owner: { select: { id: true, displayName: true, email: true } } },
    });

    if (!workspace) throw new NotFoundException('Workspace not found');
    this.assertAccess(workspace, user);
    return workspace;
  }

  async update(
    id: string,
    dto: UpdateWorkspaceDto,
    user: JwtPayload,
  ): Promise<Workspace> {
    const workspace = await this.findById(id, user);
    this.assertOwnerOrAdmin(workspace, user);

    return this.prisma.workspace.update({
      where: { id },
      data: dto,
    });
  }

  async remove(id: string, user: JwtPayload): Promise<void> {
    const workspace = await this.findById(id, user);
    this.assertOwnerOrAdmin(workspace, user);
    await this.prisma.workspace.delete({ where: { id } });
  }

  // ─── Launch / Stop ─────────────────────────────────────────────────

  async launch(id: string, user: JwtPayload): Promise<Workspace> {
    const workspace = await this.findById(id, user);

    if (workspace.status === WorkspaceStatus.RUNNING) {
      return workspace; // already running
    }

    const updated = await this.prisma.workspace.update({
      where: { id },
      data: {
        status: WorkspaceStatus.LAUNCHING,
        lastLaunchedAt: new Date(),
      },
    });

    // Cache the running status in Redis for fast lookups
    await this.redis.set(`workspace:status:${id}`, WorkspaceStatus.LAUNCHING, 3600);

    this.logger.log(`Workspace ${id} launching for user ${user.sub}`);

    // In a real deployment this would call AdsPower API / spawn browser.
    // Simulate transition to RUNNING after the launch command succeeds.
    await this.prisma.workspace.update({
      where: { id },
      data: { status: WorkspaceStatus.RUNNING },
    });
    await this.redis.set(`workspace:status:${id}`, WorkspaceStatus.RUNNING, 3600);

    return { ...updated, status: WorkspaceStatus.RUNNING };
  }

  async stop(id: string, user: JwtPayload): Promise<Workspace> {
    const workspace = await this.findById(id, user);

    const updated = await this.prisma.workspace.update({
      where: { id },
      data: { status: WorkspaceStatus.STOPPED },
    });

    await this.redis.del(`workspace:status:${id}`);
    this.logger.log(`Workspace ${id} stopped by user ${user.sub}`);

    return updated;
  }

  // ─── Access control helpers ────────────────────────────────────────

  private assertAccess(workspace: Workspace, user: JwtPayload): void {
    if (
      user.role !== Role.ADMIN &&
      user.role !== Role.MANAGER &&
      workspace.ownerId !== user.sub
    ) {
      throw new ForbiddenException('Access denied to this workspace');
    }
  }

  private assertOwnerOrAdmin(workspace: Workspace, user: JwtPayload): void {
    if (user.role !== Role.ADMIN && workspace.ownerId !== user.sub) {
      throw new ForbiddenException('Only the owner or an admin can modify this workspace');
    }
  }
}
