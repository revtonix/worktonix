/** @type {import('next').NextConfig} */
const nextConfig = {
  // Proxy API calls to the NestJS backend during development
  async rewrites() {
    return [
      {
        source: '/api/:path*',
        destination: 'http://localhost:4000/api/:path*',
      },
    ];
  },
};

module.exports = nextConfig;
