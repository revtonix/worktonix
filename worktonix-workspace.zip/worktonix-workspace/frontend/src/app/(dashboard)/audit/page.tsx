'use client';

import { useCallback, useEffect, useState } from 'react';
import { api } from '@/lib/api';
import type { AuditLog, PaginatedResponse } from '@/types';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { ScrollText, ChevronLeft, ChevronRight } from 'lucide-react';

const ACTION_COLORS: Record<string, 'default' | 'secondary' | 'destructive' | 'outline'> = {
  USER_LOGIN: 'secondary',
  USER_LOGOUT: 'outline',
  USER_CREATED: 'default',
  USER_DELETED: 'destructive',
  WORKSPACE_LAUNCHED: 'default',
  WORKSPACE_STOPPED: 'outline',
  WORKSPACE_DELETED: 'destructive',
  SECRET_CREATED: 'default',
  SECRET_DELETED: 'destructive',
};

export default function AuditPage() {
  const [logs, setLogs] = useState<AuditLog[]>([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(true);
  const limit = 25;

  const fetchLogs = useCallback(async () => {
    setLoading(true);
    try {
      const data = await api<PaginatedResponse<AuditLog>>(
        `/api/audit?page=${page}&limit=${limit}`,
      );
      setLogs(data.data);
      setTotal(data.total);
    } catch {
      // user may not have access
    } finally {
      setLoading(false);
    }
  }, [page]);

  useEffect(() => {
    fetchLogs();
  }, [fetchLogs]);

  const totalPages = Math.ceil(total / limit);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Audit Logs</h1>
        <p className="text-muted-foreground">
          View all system activity ({total} total entries)
        </p>
      </div>

      {loading ? (
        <div className="text-muted-foreground">Loading audit logs...</div>
      ) : logs.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12 text-center">
            <ScrollText className="mb-4 h-12 w-12 text-muted-foreground" />
            <p className="text-lg font-medium">No audit logs yet</p>
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Activity Timeline</CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <table className="w-full">
              <thead>
                <tr className="border-b text-left text-sm text-muted-foreground">
                  <th className="p-4">Timestamp</th>
                  <th className="p-4">Action</th>
                  <th className="p-4">User</th>
                  <th className="p-4">Target</th>
                  <th className="p-4">IP Address</th>
                </tr>
              </thead>
              <tbody>
                {logs.map((log) => (
                  <tr key={log.id} className="border-b last:border-0">
                    <td className="whitespace-nowrap p-4 text-sm">
                      {new Date(log.createdAt).toLocaleString()}
                    </td>
                    <td className="p-4">
                      <Badge variant={ACTION_COLORS[log.action] ?? 'outline'}>
                        {log.action.replace(/_/g, ' ')}
                      </Badge>
                    </td>
                    <td className="p-4 text-sm">
                      {log.user?.displayName ?? 'System'}
                    </td>
                    <td className="p-4 text-sm text-muted-foreground">
                      {log.targetType}
                      {log.targetId ? ` #${log.targetId.slice(0, 8)}` : ''}
                    </td>
                    <td className="p-4 font-mono text-xs text-muted-foreground">
                      {log.ipAddress ?? '-'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>

            {/* Pagination */}
            {totalPages > 1 && (
              <div className="flex items-center justify-between border-t p-4">
                <p className="text-sm text-muted-foreground">
                  Page {page} of {totalPages}
                </p>
                <div className="flex gap-2">
                  <Button
                    size="sm"
                    variant="outline"
                    disabled={page <= 1}
                    onClick={() => setPage((p) => p - 1)}
                  >
                    <ChevronLeft className="h-4 w-4" />
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    disabled={page >= totalPages}
                    onClick={() => setPage((p) => p + 1)}
                  >
                    <ChevronRight className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}
