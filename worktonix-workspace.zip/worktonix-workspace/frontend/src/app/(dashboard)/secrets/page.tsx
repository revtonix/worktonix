'use client';

import { useCallback, useEffect, useState } from 'react';
import { api } from '@/lib/api';
import type { Workspace, SecretSummary } from '@/types';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { KeyRound, Plus, Trash2 } from 'lucide-react';

export default function SecretsPage() {
  const [workspaces, setWorkspaces] = useState<Workspace[]>([]);
  const [selectedWorkspace, setSelectedWorkspace] = useState<string>('');
  const [secrets, setSecrets] = useState<SecretSummary[]>([]);
  const [loading, setLoading] = useState(true);

  // Create form
  const [newKey, setNewKey] = useState('');
  const [newValue, setNewValue] = useState('');

  const fetchWorkspaces = useCallback(async () => {
    try {
      const data = await api<Workspace[]>('/api/workspaces');
      setWorkspaces(data);
      if (data.length > 0 && !selectedWorkspace) {
        setSelectedWorkspace(data[0].id);
      }
    } catch {
      // ignore
    } finally {
      setLoading(false);
    }
  }, [selectedWorkspace]);

  const fetchSecrets = useCallback(async () => {
    if (!selectedWorkspace) return;
    try {
      const data = await api<SecretSummary[]>(
        `/api/workspaces/${selectedWorkspace}/secrets`,
      );
      setSecrets(data);
    } catch {
      setSecrets([]);
    }
  }, [selectedWorkspace]);

  useEffect(() => {
    fetchWorkspaces();
  }, [fetchWorkspaces]);

  useEffect(() => {
    fetchSecrets();
  }, [fetchSecrets]);

  async function handleCreate() {
    if (!newKey.trim() || !newValue.trim() || !selectedWorkspace) return;
    await api(`/api/workspaces/${selectedWorkspace}/secrets`, {
      method: 'POST',
      body: JSON.stringify({ key: newKey, value: newValue }),
    });
    setNewKey('');
    setNewValue('');
    fetchSecrets();
  }

  async function handleDelete(secretId: string) {
    if (!confirm('Delete this secret?')) return;
    await api(`/api/workspaces/${selectedWorkspace}/secrets/${secretId}`, {
      method: 'DELETE',
    });
    fetchSecrets();
  }

  if (loading) {
    return <div className="text-muted-foreground">Loading...</div>;
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Secrets</h1>
        <p className="text-muted-foreground">
          Manage encrypted secrets for your workspaces (AES-256-GCM)
        </p>
      </div>

      {/* Workspace selector */}
      <div className="flex items-center gap-3">
        <label className="text-sm font-medium">Workspace:</label>
        <select
          className="rounded-md border bg-background px-3 py-2 text-sm"
          value={selectedWorkspace}
          onChange={(e) => setSelectedWorkspace(e.target.value)}
        >
          {workspaces.map((ws) => (
            <option key={ws.id} value={ws.id}>
              {ws.name}
            </option>
          ))}
        </select>
      </div>

      {/* Add secret */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg">
            <Plus className="h-4 w-4" />
            Add Secret
          </CardTitle>
        </CardHeader>
        <CardContent className="flex gap-3">
          <Input
            placeholder="Key (e.g. API_KEY)"
            value={newKey}
            onChange={(e) => setNewKey(e.target.value)}
            className="max-w-xs"
          />
          <Input
            placeholder="Value"
            type="password"
            value={newValue}
            onChange={(e) => setNewValue(e.target.value)}
            className="max-w-xs"
          />
          <Button onClick={handleCreate} disabled={!newKey || !newValue}>
            Add
          </Button>
        </CardContent>
      </Card>

      {/* Secrets list */}
      {secrets.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12 text-center">
            <KeyRound className="mb-4 h-12 w-12 text-muted-foreground" />
            <p className="text-lg font-medium">No secrets yet</p>
            <p className="text-sm text-muted-foreground">
              Add encrypted secrets for this workspace
            </p>
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardContent className="p-0">
            <table className="w-full">
              <thead>
                <tr className="border-b text-left text-sm text-muted-foreground">
                  <th className="p-4">Key</th>
                  <th className="p-4">Value</th>
                  <th className="p-4">Created</th>
                  <th className="p-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody>
                {secrets.map((secret) => (
                  <tr key={secret.id} className="border-b last:border-0">
                    <td className="p-4 font-mono text-sm">{secret.key}</td>
                    <td className="p-4 text-sm text-muted-foreground">
                      &#8226;&#8226;&#8226;&#8226;&#8226;&#8226;&#8226;&#8226;
                    </td>
                    <td className="p-4 text-sm text-muted-foreground">
                      {new Date(secret.createdAt).toLocaleDateString()}
                    </td>
                    <td className="p-4 text-right">
                      <Button
                        size="sm"
                        variant="ghost"
                        className="text-destructive hover:text-destructive"
                        onClick={() => handleDelete(secret.id)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
