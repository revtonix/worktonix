'use client';

import { useCallback, useEffect, useState } from 'react';
import { api } from '@/lib/api';
import type { Workspace } from '@/types';
import { Button } from '@/components/ui/button';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import {
  MonitorSmartphone,
  Play,
  Square,
  Plus,
  Trash2,
} from 'lucide-react';

const STATUS_COLORS: Record<string, 'default' | 'secondary' | 'destructive' | 'outline'> = {
  IDLE: 'secondary',
  LAUNCHING: 'outline',
  RUNNING: 'default',
  STOPPED: 'secondary',
  ERROR: 'destructive',
};

export default function WorkspacesPage() {
  const [workspaces, setWorkspaces] = useState<Workspace[]>([]);
  const [loading, setLoading] = useState(true);
  const [showCreate, setShowCreate] = useState(false);
  const [newName, setNewName] = useState('');
  const [newProfileId, setNewProfileId] = useState('');
  const [newDescription, setNewDescription] = useState('');

  const fetchWorkspaces = useCallback(async () => {
    try {
      const data = await api<Workspace[]>('/api/workspaces');
      setWorkspaces(data);
    } catch {
      // silently fail — user might not have access
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchWorkspaces();
  }, [fetchWorkspaces]);

  async function handleCreate() {
    if (!newName.trim() || !newProfileId.trim()) return;
    await api('/api/workspaces', {
      method: 'POST',
      body: JSON.stringify({
        name: newName,
        profileId: newProfileId,
        description: newDescription || undefined,
      }),
    });
    setNewName('');
    setNewProfileId('');
    setNewDescription('');
    setShowCreate(false);
    fetchWorkspaces();
  }

  async function handleLaunch(id: string) {
    await api(`/api/workspaces/${id}/launch`, { method: 'POST' });
    fetchWorkspaces();
  }

  async function handleStop(id: string) {
    await api(`/api/workspaces/${id}/stop`, { method: 'POST' });
    fetchWorkspaces();
  }

  async function handleDelete(id: string) {
    if (!confirm('Are you sure you want to delete this workspace?')) return;
    await api(`/api/workspaces/${id}`, { method: 'DELETE' });
    fetchWorkspaces();
  }

  if (loading) {
    return <div className="text-muted-foreground">Loading workspaces...</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Workspaces</h1>
          <p className="text-muted-foreground">
            Manage and launch your browser workspaces
          </p>
        </div>
        <Button onClick={() => setShowCreate(!showCreate)}>
          <Plus className="mr-2 h-4 w-4" />
          New Workspace
        </Button>
      </div>

      {/* Create form */}
      {showCreate && (
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Create Workspace</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <Input
              placeholder="Workspace name"
              value={newName}
              onChange={(e) => setNewName(e.target.value)}
            />
            <Input
              placeholder="AdsPower Profile ID"
              value={newProfileId}
              onChange={(e) => setNewProfileId(e.target.value)}
            />
            <Input
              placeholder="Description (optional)"
              value={newDescription}
              onChange={(e) => setNewDescription(e.target.value)}
            />
            <div className="flex gap-2">
              <Button onClick={handleCreate} disabled={!newName || !newProfileId}>
                Create
              </Button>
              <Button variant="outline" onClick={() => setShowCreate(false)}>
                Cancel
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Workspace grid */}
      {workspaces.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12 text-center">
            <MonitorSmartphone className="mb-4 h-12 w-12 text-muted-foreground" />
            <p className="text-lg font-medium">No workspaces yet</p>
            <p className="text-sm text-muted-foreground">
              Create your first workspace to get started
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {workspaces.map((ws) => (
            <Card key={ws.id}>
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle className="text-lg">{ws.name}</CardTitle>
                    {ws.description && (
                      <CardDescription>{ws.description}</CardDescription>
                    )}
                  </div>
                  <Badge variant={STATUS_COLORS[ws.status] ?? 'outline'}>
                    {ws.status}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent>
                <div className="mb-4 space-y-1 text-sm text-muted-foreground">
                  <p>Profile: {ws.profileId}</p>
                  {ws.owner && <p>Owner: {ws.owner.displayName}</p>}
                  {ws.lastLaunchedAt && (
                    <p>
                      Last launched:{' '}
                      {new Date(ws.lastLaunchedAt).toLocaleString()}
                    </p>
                  )}
                </div>
                <div className="flex gap-2">
                  {ws.status === 'RUNNING' ? (
                    <Button
                      size="sm"
                      variant="destructive"
                      onClick={() => handleStop(ws.id)}
                    >
                      <Square className="mr-1 h-3 w-3" />
                      Stop
                    </Button>
                  ) : (
                    <Button size="sm" onClick={() => handleLaunch(ws.id)}>
                      <Play className="mr-1 h-3 w-3" />
                      Launch
                    </Button>
                  )}
                  <Button
                    size="sm"
                    variant="ghost"
                    className="text-destructive hover:text-destructive"
                    onClick={() => handleDelete(ws.id)}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
