'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import {
  LayoutDashboard,
  MonitorSmartphone,
  KeyRound,
  ScrollText,
  Users,
  LogOut,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { useAuth } from '@/hooks/use-auth';
import { Button } from '@/components/ui/button';

const NAV_ITEMS = [
  { href: '/workspaces', label: 'Workspaces', icon: MonitorSmartphone },
  { href: '/secrets', label: 'Secrets', icon: KeyRound, roles: ['ADMIN', 'MANAGER'] },
  { href: '/audit', label: 'Audit Logs', icon: ScrollText, roles: ['ADMIN', 'MANAGER'] },
  { href: '/users', label: 'Users', icon: Users, roles: ['ADMIN'] },
] as const;

export function Sidebar() {
  const pathname = usePathname();
  const { user, logout } = useAuth();

  return (
    <aside className="flex h-screen w-64 flex-col border-r bg-card">
      {/* Logo */}
      <div className="flex h-16 items-center gap-2 border-b px-6">
        <LayoutDashboard className="h-6 w-6 text-primary" />
        <span className="text-lg font-bold">WorkTonix</span>
      </div>

      {/* Navigation */}
      <nav className="flex-1 space-y-1 p-4">
        {NAV_ITEMS.map((item) => {
          // Hide items the user's role doesn't allow
          if (item.roles && user && !item.roles.includes(user.role)) {
            return null;
          }

          const active = pathname.startsWith(item.href);
          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                'flex items-center gap-3 rounded-md px-3 py-2 text-sm font-medium transition-colors',
                active
                  ? 'bg-primary/10 text-primary'
                  : 'text-muted-foreground hover:bg-accent hover:text-foreground',
              )}
            >
              <item.icon className="h-4 w-4" />
              {item.label}
            </Link>
          );
        })}
      </nav>

      {/* User info + logout */}
      <div className="border-t p-4">
        <div className="mb-2 text-sm">
          <p className="font-medium">{user?.displayName}</p>
          <p className="text-xs text-muted-foreground">{user?.role}</p>
        </div>
        <Button variant="ghost" size="sm" className="w-full justify-start gap-2" onClick={logout}>
          <LogOut className="h-4 w-4" />
          Logout
        </Button>
      </div>
    </aside>
  );
}
