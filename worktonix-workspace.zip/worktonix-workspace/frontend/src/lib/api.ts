/**
 * Thin HTTP client that handles JWT token lifecycle.
 * - Stores the access token in memory (never localStorage)
 * - Automatically attempts a silent refresh on 401
 */

let accessToken: string | null = null;

export function setAccessToken(token: string | null): void {
  accessToken = token;
}

export function getAccessToken(): string | null {
  return accessToken;
}

interface FetchOptions extends RequestInit {
  /** Skip adding the Authorization header */
  noAuth?: boolean;
}

async function refreshAccessToken(): Promise<boolean> {
  try {
    const res = await fetch('/api/auth/refresh', {
      method: 'POST',
      credentials: 'include', // sends the HttpOnly cookie
    });
    if (!res.ok) return false;

    const body = (await res.json()) as { accessToken: string };
    setAccessToken(body.accessToken);
    return true;
  } catch {
    return false;
  }
}

/**
 * Wrapper around fetch that injects the JWT and handles token refresh.
 * Throws on non-2xx responses with a parsed error message.
 */
export async function api<T = unknown>(
  url: string,
  options: FetchOptions = {},
): Promise<T> {
  const headers = new Headers(options.headers);

  if (!options.noAuth && accessToken) {
    headers.set('Authorization', `Bearer ${accessToken}`);
  }

  if (options.body && !headers.has('Content-Type')) {
    headers.set('Content-Type', 'application/json');
  }

  let res = await fetch(url, {
    ...options,
    headers,
    credentials: 'include',
  });

  // On 401, try silent refresh once
  if (res.status === 401 && !options.noAuth) {
    const refreshed = await refreshAccessToken();
    if (refreshed) {
      headers.set('Authorization', `Bearer ${accessToken}`);
      res = await fetch(url, { ...options, headers, credentials: 'include' });
    }
  }

  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    const message =
      (body as { message?: string | string[] }).message ?? 'Request failed';
    throw new Error(Array.isArray(message) ? message.join(', ') : message);
  }

  // Handle 204 No Content
  if (res.status === 204) return undefined as T;

  return res.json() as Promise<T>;
}
