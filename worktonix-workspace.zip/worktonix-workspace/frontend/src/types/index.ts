// ─── User ────────────────────────────────────────────────────────────────────

export type Role = 'ADMIN' | 'MANAGER' | 'OPERATOR';

export interface User {
  id: string;
  email: string;
  displayName: string;
  role: Role;
  isActive: boolean;
  lastLoginAt: string | null;
  createdAt: string;
  updatedAt: string;
}

// ─── Workspace ───────────────────────────────────────────────────────────────

export type WorkspaceStatus = 'IDLE' | 'LAUNCHING' | 'RUNNING' | 'STOPPED' | 'ERROR';

export interface Workspace {
  id: string;
  name: string;
  description: string | null;
  profileId: string;
  launchUrl: string | null;
  status: WorkspaceStatus;
  config: Record<string, unknown>;
  ownerId: string;
  owner?: { id: string; displayName: string; email: string };
  lastLaunchedAt: string | null;
  createdAt: string;
  updatedAt: string;
}

// ─── Secret ──────────────────────────────────────────────────────────────────

export interface SecretSummary {
  id: string;
  workspaceId: string;
  key: string;
  createdAt: string;
  updatedAt: string;
}

// ─── Audit ───────────────────────────────────────────────────────────────────

export type AuditAction =
  | 'USER_LOGIN'
  | 'USER_LOGOUT'
  | 'USER_CREATED'
  | 'USER_UPDATED'
  | 'USER_DELETED'
  | 'WORKSPACE_CREATED'
  | 'WORKSPACE_UPDATED'
  | 'WORKSPACE_DELETED'
  | 'WORKSPACE_LAUNCHED'
  | 'WORKSPACE_STOPPED'
  | 'SECRET_CREATED'
  | 'SECRET_UPDATED'
  | 'SECRET_DELETED'
  | 'SECRET_ACCESSED';

export interface AuditLog {
  id: string;
  action: AuditAction;
  userId: string | null;
  user?: { id: string; displayName: string; email: string } | null;
  targetType: string | null;
  targetId: string | null;
  metadata: Record<string, unknown>;
  ipAddress: string | null;
  userAgent: string | null;
  createdAt: string;
}

export interface PaginatedResponse<T> {
  data: T[];
  total: number;
  page: number;
  limit: number;
}
